import { FormEvent, useState } from "react";
import { confirmPasswordReset, verifyEmail } from "../services/api";

export default function AuthActionPage({ path, onDone }: { path: string; onDone: () => void }) {
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const verifyMatch = path.match(/^\/verify-email\/([^/]+)/);
  const resetMatch = path.match(/^\/password\/reset\/confirm\/([^/]+)\/([^/]+)/);

  const reset = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const password = String(new FormData(event.currentTarget).get("password") || "");
    try { await confirmPasswordReset(resetMatch![1], resetMatch![2], password); setMessage("Password updated. You can now sign in."); setError(""); } catch (actionError: any) { setError(actionError.message); }
  };

  return <main className="mx-auto flex min-h-[70vh] w-full max-w-lg items-center px-4"><section className="w-full rounded-2xl border border-slate-100 bg-white p-8 shadow-xl"><h1 className="text-2xl font-bold text-[#001142]">{verifyMatch ? "Verify your email" : "Choose a new password"}</h1><p className="mt-2 text-sm text-slate-500">Secure your Job Portal account.</p>{verifyMatch && !message && <button onClick={async()=>{try{await verifyEmail(verifyMatch[1]);setMessage("Email verified. You can now sign in.");}catch(actionError:any){setError(actionError.message);}}} className="mt-6 w-full rounded-lg bg-[#016a61] py-3 font-bold text-white">Verify email</button>}{resetMatch && !message && <form onSubmit={reset} className="mt-6 space-y-4"><input name="password" type="password" minLength={10} required placeholder="New password" className="w-full rounded-lg border p-3"/><button className="w-full rounded-lg bg-[#016a61] py-3 font-bold text-white">Update password</button></form>}{message&&<div className="mt-6 rounded-lg bg-emerald-50 p-4 text-sm text-emerald-700">{message}</div>}{error&&<div className="mt-6 rounded-lg bg-red-50 p-4 text-sm text-red-600">{error}</div>}<button onClick={onDone} className="mt-5 text-sm font-bold text-[#016a61]">Return to sign in</button></section></main>;
}
