/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Mail, Lock, User, GraduationCap } from "lucide-react";
import type { User as AuthUser } from "../types";
import { googleLogin, login as loginAccount, requestPasswordReset } from "../services/api";

declare global {
  interface Window { google?: any; }
}

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: AuthUser) => void;
  initialMode?: "login" | "register";
  userRole: "student" | "recruiter";
  setUserRole: (r: "student" | "recruiter") => void;
  companyName: string;
  setCompanyName: (s: string) => void;
  university: string;
  setUniversity: (s: string) => void;
  onRegister?: (payload: any) => Promise<any>;
}

export default function LoginModal({
  isOpen,
  onClose,
  onLoginSuccess,
  initialMode = "login",
  userRole,
  setUserRole,
  companyName,
  setCompanyName,
  university,
  setUniversity,
  onRegister,
}: LoginModalProps) {
  const [mode, setMode] = useState<"login" | "register">(initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const googleButtonRef = useRef<HTMLDivElement>(null);
  const googleClientId = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined;

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setError("");
      setSuccessMessage("");
      setLoading(false);
    }
  }, [initialMode, isOpen]);

  useEffect(() => {
    if (!isOpen || !googleClientId || !googleButtonRef.current) return;
    const render = () => {
      if (!window.google || !googleButtonRef.current) return;
      window.google.accounts.id.initialize({
        client_id: googleClientId,
        callback: async ({ credential }: { credential: string }) => {
          setLoading(true);
          setError("");
          try {
            const user = await googleLogin({ id_token: credential, role: userRole, full_name: name, university, company_name: companyName });
            onLoginSuccess(user);
            onClose();
          } catch (googleError: any) {
            setError(googleError?.message || "Google sign-in failed.");
          } finally { setLoading(false); }
        },
      });
      window.google.accounts.id.renderButton(googleButtonRef.current, { theme: "outline", size: "large", width: 350 });
    };
    const existing = document.getElementById("google-identity-script");
    if (existing) { render(); return; }
    const script = document.createElement("script");
    script.id = "google-identity-script";
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.onload = render;
    document.head.appendChild(script);
  }, [isOpen, googleClientId, userRole, name, university, companyName]);

  const passwordError =
    mode === "register" &&
    password.length > 0 &&
    (!/^.{10,}$/.test(password) ||
      !/[A-Za-z]/.test(password) ||
      !/[0-9]/.test(password))
      ? "Password must be at least 10 characters long and include at least one letter and one number. Avoid common passwords and passwords similar to your name or email."
      : "";

  const clearRegistrationState = () => {
    setPassword("");
    setName("");
    setCompanyName("");
    setUniversity("");
    setUserRole("student");
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMessage("");

    if (!email || !password) {
      setError("Please fill in all standard credentials.");
      return;
    }

    if (mode === "register") {
      if (!name) {
        setError("Please provide your full name.");
        return;
      }
      if (userRole === "student" && !university) {
        setError("Please provide your university name.");
        return;
      }
      if (userRole === "recruiter" && !companyName) {
        setError("Please provide your company name.");
        return;
      }
      if (passwordError) {
        setError(passwordError);
        return;
      }
    }

    const proceed = async () => {
      setLoading(true);
      try {
        if (mode === "register") {
          if (!onRegister) throw new Error("No register handler provided");

          const payload: any = {
            email,
            password,
            role: userRole,
            full_name: name,
            company_name: companyName || "",
            university: university || "",
          };

          const result = await onRegister(payload);
          if (result?.message) {
            clearRegistrationState();
            setMode("login");
            setError("");
            setSuccessMessage(result.message);
          } else {
            setError("Registration failed.");
          }
        } else {
          const user = await loginAccount(email, password);
          onLoginSuccess(user);
          onClose();
        }
      } catch (err: any) {
        setSuccessMessage("");
        setError(err?.message || "An error occurred");
      } finally {
        setLoading(false);
      }
    };

    proceed();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#001142]/40 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="relative w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100/80 z-10"
          >
            <div className="h-2 bg-[#016a61]" />

            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3
                    id="modal-title"
                    className="text-2xl font-bold text-[#001142]"
                  >
                    {mode === "login"
                      ? "Welcome Back"
                      : "Create Student Account"}
                  </h3>
                  <p className="text-slate-500 text-sm mt-1">
                    {mode === "login"
                      ? "Access campus opportunities instantly"
                      : "Bridge academic ambition and career growth"}
                  </p>
                </div>
                <button
                  id="close-login-modal"
                  onClick={onClose}
                  className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                {mode === "login" && (
                  <button
                    type="button"
                    onClick={async () => {
                      if (!email) return setError("Enter your email address first.");
                      try {
                        await requestPasswordReset(email);
                        setSuccessMessage("If that account exists, a reset link has been sent.");
                        setError("");
                      } catch (resetError: any) {
                        setError(resetError?.message || "Unable to request a password reset.");
                      }
                    }}
                    className="w-full text-xs font-semibold text-[#016a61] hover:text-[#005049]"
                  >
                    Forgot password?
                  </button>
                )}
              </div>

              {successMessage && (
                <div className="mb-4 p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs rounded-lg font-medium">
                  {successMessage}
                </div>
              )}

              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-100 text-red-600 text-xs rounded-lg font-medium">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === "register" && (
                  <>
                    <div className="flex gap-3 mb-2">
                      <button
                        type="button"
                        onClick={() => setUserRole("student")}
                        className={`px-3 py-2 rounded-lg border font-medium ${userRole === "student" ? "bg-[#016a61] text-white" : "bg-white text-slate-600"}`}
                      >
                        I am a Student
                      </button>
                      <button
                        type="button"
                        onClick={() => setUserRole("recruiter")}
                        className={`px-3 py-2 rounded-lg border font-medium ${userRole === "recruiter" ? "bg-[#016a61] text-white" : "bg-white text-slate-600"}`}
                      >
                        I am an Employer
                      </button>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-[#001142] uppercase tracking-wider mb-2">
                        Full Name
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input
                          id="register-name-field"
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Alex Smith"
                          className="w-full text-sm pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 outline-none focus:border-[#001142] transition-all bg-slate-50/50"
                        />
                      </div>
                    </div>

                    {userRole === "recruiter" ? (
                      <div>
                        <label className="block text-xs font-semibold text-[#001142] uppercase tracking-wider mb-2">
                          Company Name
                        </label>
                        <div className="relative">
                          <input
                            id="register-company-field"
                            type="text"
                            required
                            value={companyName}
                            onChange={(e) => setCompanyName(e.target.value)}
                            placeholder="Acme Corp"
                            className="w-full text-sm pl-4 pr-4 py-2.5 rounded-lg border border-slate-200 outline-none focus:border-[#001142] transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>
                    ) : (
                      <div>
                        <label className="block text-xs font-semibold text-[#001142] uppercase tracking-wider mb-2">
                          University Name
                        </label>
                        <div className="relative">
                          <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                          <input
                            id="register-university-field"
                            type="text"
                            required
                            value={university}
                            onChange={(e) => setUniversity(e.target.value)}
                            placeholder="Stanford University"
                            className="w-full text-sm pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 outline-none focus:border-[#001142] transition-all bg-slate-50/50"
                          />
                        </div>
                      </div>
                    )}
                  </>
                )}

                <div>
                  <label className="block text-xs font-semibold text-[#001142] uppercase tracking-wider mb-2">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      id="login-email-field"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="alex.smith@university.edu"
                      className="w-full text-sm pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 outline-none focus:border-[#001142] transition-all bg-slate-50/50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#001142] uppercase tracking-wider mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      id="login-password-field"
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="********"
                      className="w-full text-sm pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 outline-none focus:border-[#001142] transition-all bg-slate-50/50"
                    />
                  </div>
                  {mode === "register" && passwordError && (
                    <p className="mt-2 text-xs text-red-600">{passwordError}</p>
                  )}
                </div>

                <button
                  id="submit-auth-btn"
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 bg-[#016a61] hover:bg-[#005049] text-white font-medium text-sm py-3 rounded-lg flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-95 transition-all text-center"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : mode === "login" ? (
                    "Log In"
                  ) : (
                    "Register Account"
                  )}
                </button>
              </form>

              <div className="mt-6 pt-5 border-t border-slate-100 text-center">
                {googleClientId && <div ref={googleButtonRef} className="mb-5 flex justify-center" />}
                <p className="text-sm text-slate-500">
                  {mode === "login"
                    ? "Don't have an account yet?"
                    : "Already registered?"}
                  <button
                    id="switch-auth-mode-btn"
                    onClick={() => {
                      setMode(mode === "login" ? "register" : "login");
                      setError("");
                      setSuccessMessage("");
                    }}
                    className="ml-2 font-semibold text-[#016a61] hover:text-[#005049] transition-colors"
                  >
                    {mode === "login" ? "Create one" : "Sign In"}
                  </button>
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
