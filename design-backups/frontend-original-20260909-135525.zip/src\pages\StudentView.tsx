/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  Search,
  Briefcase,
  Clock,
  MapPin,
  Code,
  ChevronDown,
  SlidersHorizontal,
  X,
} from "lucide-react";

import type { FilterState, Job } from "../types";
import { fetchJobs } from "../services/api";

const defaultFilters: FilterState = {
  jobTypes: {
    Internship: false,
    "Part-Time": false,
    "Full-Time": false,
    Remote: false,
  },
  industries: {
    "Computer Science": false,
  },
};

export interface StudentViewProps {
  isLoggedIn: boolean;
  onOpenLogin: (mode?: "login" | "register") => void;
  onOpenApplication: (job: Job) => void;
}

export default function StudentView({
  isLoggedIn,
  onOpenLogin,
  onOpenApplication,
}: StudentViewProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [appliedSearchQuery, setAppliedSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<
    "Newest" | "Highest Compensation" | "Alphabetical"
  >("Newest");
  const [isSortOpen, setIsSortOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [appliedJobIds, setAppliedJobIds] = useState<Set<string>>(new Set());
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  useEffect(() => {
    fetchJobs()
      .then(setJobs)
      .catch((error: Error) => setLoadError(error.message))
      .finally(() => setIsLoading(false));
  }, []);

  const filteredJobs = useMemo(() => {
    let result = [...jobs];

    const normalizedQuery = appliedSearchQuery.trim().toLowerCase();
    if (normalizedQuery) {
      result = result.filter(
        (job) =>
          job.title.toLowerCase().includes(normalizedQuery) ||
          job.company.toLowerCase().includes(normalizedQuery),
      );
    }

    const checkedTypes = Object.entries(filters.jobTypes)
      .filter(([_, checked]) => checked)
      .map(([type]) => type);

    if (checkedTypes.length > 0) {
      result = result.filter((job) => checkedTypes.includes(job.jobType));
    }

    const checkedIndustries = Object.entries(filters.industries)
      .filter(([_, checked]) => checked)
      .map(([industry]) => industry);

    if (checkedIndustries.length > 0) {
      result = result.filter((job) => checkedIndustries.includes(job.industry));
    }

    if (sortBy === "Highest Compensation") {
      result.sort((a, b) => {
        const valA = parseInt(a.compensation.replace(/[^0-9]/g, ""), 10) || 0;
        const valB = parseInt(b.compensation.replace(/[^0-9]/g, ""), 10) || 0;
        return valB - valA;
      });
    } else if (sortBy === "Alphabetical") {
      result.sort((a, b) => a.title.localeCompare(b.title));
    } else {
      result.sort((a, b) => parseInt(a.id, 10) - parseInt(b.id, 10));
    }

    return result;
  }, [appliedSearchQuery, filters, jobs, sortBy]);

  const opportunitiesHeading = useMemo(() => {
    const count = filteredJobs.length;
    return `${count} ${count === 1 ? "Opportunity" : "Opportunities"} Found`;
  }, [filteredJobs]);

  const handleToggleJobType = (key: keyof FilterState["jobTypes"]) => {
    setFilters((prev) => ({
      ...prev,
      jobTypes: {
        ...prev.jobTypes,
        [key]: !prev.jobTypes[key],
      },
    }));
  };

  const handleToggleIndustry = (key: keyof FilterState["industries"]) => {
    setFilters((prev) => ({
      ...prev,
      industries: {
        ...prev.industries,
        [key]: !prev.industries[key],
      },
    }));
  };

  const handleClearFilters = () => {
    setFilters(defaultFilters);
    setSearchQuery("");
    setAppliedSearchQuery("");
  };

  const handleSearchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setAppliedSearchQuery(searchQuery);
  };

  const handleApplyJob = (job: Job) => {
    if (!isLoggedIn) {
      onOpenLogin("login");
      return;
    }

    onOpenApplication(job);
  };

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-1">
      <section className="bg-gradient-to-b from-[#e5eeff]/40 via-[#e5eeff]/10 to-brand-bg relative pt-20 pb-16 overflow-hidden -mx-4 sm:-mx-6 lg:-mx-8 mb-10">
        <div className="absolute right-[-10%] top-[-10%] w-[400px] h-[400px] rounded-full bg-[#016a61]/5 blur-3xl pointer-events-none" />
        <div className="absolute left-[-5%] bottom-[-5%] w-[300px] h-[300px] rounded-full bg-[#425aa6]/5 blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8 relative z-10">
          <div className="space-y-4">
            <h1 className="text-4xl md:text-[52px] font-extrabold tracking-tight text-[#001142] leading-[1.12]">
              Find Your Next{" "}
              <span className="text-[#016a61] relative">Internship</span> or{" "}
              <br className="hidden md:block" />
              Graduate Role
            </h1>
           
          </div>

          <form
            onSubmit={handleSearchSubmit}
            className="max-w-2xl mx-auto bg-white border border-slate-100 rounded-2xl p-2.5 shadow-[0_10px_35px_rgba(0,35,111,0.06)] flex items-center"
          >
            <div className="flex-1 flex items-center pl-4 pr-2">
              <Search className="w-5 h-5 text-slate-400 shrink-0 mr-3" />
              <input
                id="search-input-field"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by job title or company..."
                className="w-full text-sm outline-none text-[#001142] placeholder:text-slate-400 font-medium py-2.5"
              />
            </div>
            <button
              id="search-action-btn"
              type="submit"
              className="bg-[#001142] hover:bg-[#0b1c30] text-white font-semibold text-sm px-6 py-3.5 rounded-xl cursor-pointer hover:shadow-lg transition-all shrink-0 active:scale-95"
            >
              Search Jobs
            </button>
          </form>
        </div>
      </section>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        <aside className="w-full lg:w-[280px] shrink-0 bg-white rounded-xl border border-slate-100 p-6 shadow-[0_4px_16px_rgba(0,35,111,0.02)] space-y-6">
          <div>
            <h2 className="text-lg font-bold text-[#001142]">Filters</h2>
            <p className="text-xs text-slate-400 font-medium mt-1">
              Refine your search
            </p>
          </div>

          <div className="pt-5 border-t border-slate-100">
            <h3 className="text-xs font-bold text-[#001142] tracking-wider uppercase mb-4">
              Job Type
            </h3>
            <div className="space-y-3">
              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-internship-chk"
                    type="checkbox"
                    checked={filters.jobTypes.Internship}
                    onChange={() => handleToggleJobType("Internship")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61] focus:ring-0 focus:outline-none focus:border-[#016a61]"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <Briefcase className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Internship</span>
                  </div>
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-parttime-chk"
                    type="checkbox"
                    checked={filters.jobTypes["Part-Time"]}
                    onChange={() => handleToggleJobType("Part-Time")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61] focus:ring-0 focus:outline-none focus:border-[#016a61]"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <Clock className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Part-Time</span>
                  </div>
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-fulltime-chk"
                    type="checkbox"
                    checked={filters.jobTypes["Full-Time"]}
                    onChange={() => handleToggleJobType("Full-Time")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61] focus:ring-0 focus:outline-none"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <Briefcase className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Full-Time</span>
                  </div>
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-remote-chk"
                    type="checkbox"
                    checked={filters.jobTypes.Remote}
                    onChange={() => handleToggleJobType("Remote")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61] focus:ring-0 focus:outline-none"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <MapPin className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Remote</span>
                  </div>
                </div>
              </label>
            </div>
          </div>
          {/* 
          <div className="pt-6 border-t border-slate-100">
            <h3 className="text-xs font-bold text-[#001142] tracking-wider uppercase mb-4">
              Major / Industry
            </h3>
            <div className="space-y-3">
              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-cs-chk"
                    type="checkbox"
                    checked={filters.industries["Computer Science"]}
                    onChange={() => handleToggleIndustry("Computer Science")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61]"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <Code className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">
                      Computer Science
                    </span>
                  </div>
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-engineering-chk"
                    type="checkbox"
                    checked={filters.industries.Engineering}
                    onChange={() => handleToggleIndustry("Engineering")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61]"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <Settings className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Engineering</span>
                  </div>
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-business-chk"
                    type="checkbox"
                    checked={filters.industries.Business}
                    onChange={() => handleToggleIndustry("Business")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61]"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <SlidersHorizontal className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Business</span>
                  </div>
                </div>
              </label>

              <label className="flex items-center justify-between cursor-pointer group">
                <div className="flex items-center gap-3">
                  <input
                    id="filter-design-chk"
                    type="checkbox"
                    checked={filters.industries.Design}
                    onChange={() => handleToggleIndustry("Design")}
                    className="peer h-5 w-5 shrink-0 rounded border border-slate-300 pointer-events-none accent-[#016a61]"
                  />
                  <div className="flex items-center gap-2 text-slate-600 group-hover:text-[#001142] transition-colors">
                    <Palette className="w-4 h-4 text-slate-400 group-hover:text-[#016a61]" />
                    <span className="text-sm font-medium">Design</span>
                  </div>
                </div>
              </label>
            </div>
          </div> */}

          <div className="pt-6 border-t border-slate-100 flex justify-center">
            <button
              id="clear-filters-btn"
              type="button"
              onClick={handleClearFilters}
              className="text-sm font-semibold text-red-600 hover:text-red-500 cursor-pointer p-2 flex items-center gap-1.5 hover:bg-red-50 rounded-lg transition-all"
            >
              <X className="w-4 h-4" />
              <span>Clear All Filters</span>
            </button>
          </div>
        </aside>

        <div className="flex-1 w-full space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xl text-[#001142]">
              {opportunitiesHeading}
            </h3>

            <div className="relative">
              <div className="flex items-center gap-2 text-sm text-slate-500 font-medium">
                <span>Sort by:</span>
                <button
                  id="sort-trigger"
                  type="button"
                  onClick={() => setIsSortOpen((prev) => !prev)}
                  className="flex items-center gap-1.5 text-[#001142] font-bold hover:text-[#016a61] focus:outline-none pb-0.5 cursor-pointer selection:bg-transparent"
                >
                  <span>{sortBy}</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform duration-200 ${isSortOpen ? "rotate-180" : ""}`}
                  />
                </button>
              </div>

              <AnimatePresence>
                {isSortOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setIsSortOpen(false)}
                    />
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 5 }}
                      className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-lg border border-slate-100/80 p-1.5 z-50 text-left"
                    >
                      <button
                        id="sort-newest"
                        type="button"
                        onClick={() => {
                          setSortBy("Newest");
                          setIsSortOpen(false);
                        }}
                        className={`w-full text-left text-xs font-semibold px-4 py-3.5 rounded-lg transition-colors ${sortBy === "Newest" ? "bg-[#eff4ff] text-[#001142]" : "text-slate-600 hover:bg-slate-50"}`}
                      >
                        Newest
                      </button>
                      <button
                        id="sort-compensation"
                        type="button"
                        onClick={() => {
                          setSortBy("Highest Compensation");
                          setIsSortOpen(false);
                        }}
                        className={`w-full text-left text-xs font-semibold px-4 py-3.5 rounded-lg transition-colors ${sortBy === "Highest Compensation" ? "bg-[#eff4ff] text-[#001142]" : "text-slate-600 hover:bg-slate-50"}`}
                      >
                        Highest Compensation
                      </button>
                      <button
                        id="sort-alphabetical"
                        type="button"
                        onClick={() => {
                          setSortBy("Alphabetical");
                          setIsSortOpen(false);
                        }}
                        className={`w-full text-left text-xs font-semibold px-4 py-3.5 rounded-lg transition-colors ${sortBy === "Alphabetical" ? "bg-[#eff4ff] text-[#001142]" : "text-slate-600 hover:bg-slate-50"}`}
                      >
                        Alphabetical
                      </button>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="space-y-4">
            {isLoading && (
              <div className="bg-white border border-slate-100 rounded-xl p-10 text-center text-slate-500">
                Loading opportunities...
              </div>
            )}
            {loadError && (
              <div className="bg-red-50 border border-red-100 rounded-xl p-5 text-center text-red-600">
                {loadError}
              </div>
            )}
            <AnimatePresence mode="popLayout">
              {!isLoading && filteredJobs.length > 0 ? (
                filteredJobs.map((job) => {
                  const isAlreadyApplied = appliedJobIds.has(job.id);

                  return (
                    <motion.div
                      layout
                      key={job.id}
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ type: "spring", duration: 0.4 }}
                      className="bg-white border border-slate-100 rounded-xl p-6 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 relative group overflow-hidden border-l-4 border-l-transparent hover:border-l-[#016a61]"
                    >
                      <div className="flex flex-col md:flex-row justify-between md:items-center gap-6">
                        <div className="space-y-3.5 text-left">
                          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                            <span className="bg-[#eafaf7] text-[#016a61] px-2.5 py-1 rounded-full text-[11px] font-medium tracking-wide">
                              {job.jobType}
                            </span>
                            <span className="text-slate-300">•</span>
                            <span className="text-slate-500 text-[11px]">
                              {job.industry}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h4 className="text-xl font-bold text-[#001142] leading-tight select-all">
                              {job.title}
                            </h4>
                            <p className="text-sm font-semibold text-[#016a61]">
                              {job.company}
                            </p>
                          </div>

                          <div className="flex flex-wrap gap-2 pt-1.5">
                            {job.skills.map((skill) => (
                              <span
                                key={skill}
                                className="text-[11px] bg-[#eff4ff] text-[#425aa6] px-3 py-1 rounded-full font-medium"
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="flex md:flex-col justify-between items-end md:text-right shrink-0 min-w-[140px] md:space-y-4 pt-4 md:pt-0 border-t md:border-t-0 border-slate-100">
                          <div>
                            <div className="text-[10px] tracking-wider uppercase font-bold text-slate-400">
                              Compensation
                            </div>
                            <div className="text-lg font-extrabold text-[#001142] mt-0.5">
                              {job.compensation}
                            </div>
                          </div>

                          <button
                            id={`apply-btn-job-${job.id}`}
                            type="button"
                            disabled={isAlreadyApplied}
                            onClick={() => handleApplyJob(job)}
                            className={`px-5 py-2.5 rounded-lg font-bold text-sm transition-all focus:outline-none hover:scale-[1.02] cursor-pointer ${isAlreadyApplied ? "bg-slate-100 text-slate-400 border border-slate-200 hover:scale-100 select-none" : "bg-[#016a61] hover:bg-[#005049] text-white"}`}
                          >
                            {isAlreadyApplied ? "✓ Applied" : "Apply Now"}
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              ) : (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white border border-slate-100 rounded-xl p-12 text-center flex flex-col items-center justify-center space-y-4"
                >
                  <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                    <SlidersHorizontal className="w-6 h-6" />
                  </div>
                  <div className="space-y-1.5 text-center">
                    <h4 className="font-bold text-lg text-[#001142]">
                      No Opportunities Found
                    </h4>
                    <p className="text-slate-500 text-sm max-w-sm">
                      No positions match your selected filter criteria. Try
                      expanding your search queries.
                    </p>
                  </div>
                  <button
                    id="reset-empty-filters"
                    type="button"
                    onClick={handleClearFilters}
                    className="px-5 py-2.5 bg-[#001142] text-white text-xs font-semibold rounded-lg hover:bg-[#0b1c30] hover:scale-[1.01] transition-all cursor-pointer"
                  >
                    Clear All Filters
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </main>
  );
}
