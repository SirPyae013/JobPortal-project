/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Bell, LogOut } from "lucide-react";

export interface NavbarProps {
  isLoggedIn: boolean;
  currentUserName: string;
  profilePhotoUrl?: string;
  userRole: "student" | "recruiter";
  canManageJobs: boolean;
  onLoginClick: () => void;
  onLogout: () => void;
  onBrowseJobs: () => void;
  onPostJob: () => void;
  onMyProfile: () => void;
  onMyApplications: () => void;
  onAboutClick: () => void;
  onContactClick: () => void;
  onNotifications: () => void;
  unreadCount: number;
}

export default function Navbar({
  isLoggedIn,
  currentUserName,
  profilePhotoUrl,
  userRole,
  canManageJobs,
  onLoginClick,
  onLogout,
  onBrowseJobs,
  onPostJob,
  onMyProfile,
  onMyApplications,
  onAboutClick,
  onContactClick,
  onNotifications,
  unreadCount,
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-[0_4px_24px_rgba(0,35,111,0.02)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex justify-between items-center">
        <div className="flex items-center gap-10">
          <div className="flex items-center gap-3">
            <a href="/jobs" className="flex items-center gap-2 select-none">
              <span className="text-[#001142] font-extrabold text-2xl tracking-tight">
                Job <span className="text-[#016a61]">Portal</span>
              </span>
            </a>

          </div>

          <nav className="hidden md:flex items-center gap-8 text-[#001142] font-semibold text-sm">
            <button
              type="button"
              onClick={onBrowseJobs}
              className="relative py-2 px-1 cursor-pointer hover:text-[#016a61] transition-colors"
            >
              <span>Browse Jobs</span>
              <div className="absolute h-[3px] bg-[#001142] bottom-0 left-0 right-0 rounded-full" />
            </button>

            {isLoggedIn ? (
              userRole === "recruiter" ? (
                <>
                  {canManageJobs && <button
                    id="post-job-btn"
                    type="button"
                    onClick={onPostJob}
                    className="bg-[#016a61] text-white px-3 py-2 rounded-lg hover:bg-[#005049] transition-all"
                  >
                    + Post a Job
                  </button>}
                  <button
                    id="nav-about-us"
                    type="button"
                    onClick={onAboutClick}
                    className="hover:text-[#016a61] transition-colors py-2"
                  >
                    About Us
                  </button>
                  <button
                    id="nav-contact"
                    type="button"
                    onClick={onContactClick}
                    className="hover:text-[#016a61] transition-colors py-2"
                  >
                    Contact
                  </button>
                </>
              ) : (
                <>
                  <button
                    id="my-profile-btn"
                    type="button"
                    onClick={onMyProfile}
                    className="hover:text-[#016a61] transition-colors py-2"
                  >
                    My Profile
                  </button>
                  <button
                    id="my-apps-btn"
                    type="button"
                    onClick={onMyApplications}
                    className="hover:text-[#016a61] transition-colors py-2"
                  >
                    My Applications
                  </button>
                  <button
                    id="nav-about-us"
                    type="button"
                    onClick={onAboutClick}
                    className="hover:text-[#016a61] transition-colors py-2"
                  >
                    About Us
                  </button>
                  <button
                    id="nav-contact"
                    type="button"
                    onClick={onContactClick}
                    className="hover:text-[#016a61] transition-colors py-2"
                  >
                    Contact
                  </button>
                </>
              )
            ) : null}
          </nav>
        </div>

        <div className="flex items-center gap-4 text-sm font-semibold text-[#001142]">
          {!isLoggedIn ? (
            <button
              id="header-register-btn"
              type="button"
              onClick={onLoginClick}
              className="bg-[#016a61] text-white hover:bg-[#005049] px-5 py-2.5 rounded-lg active:scale-95 transition-all outline-none font-semibold hover:shadow-md hover:shadow-[#016a61]/10"
            >
              Login
            </button>
          ) : (
            <div className="flex items-center gap-3 bg-[#eff4ff]/60 border border-[#d3e4fe]/50 px-4 py-2 rounded-xl">
              <button type="button" onClick={onNotifications} className="relative rounded-md p-1 text-[#001142] hover:bg-white" title="Notifications"><Bell className="h-4 w-4"/>{unreadCount>0&&<span className="absolute -right-1 -top-1 min-w-4 rounded-full bg-red-500 px-1 text-[9px] text-white">{unreadCount}</span>}</button>
              <div className="w-7 h-7 overflow-hidden rounded-full bg-[#001142] flex items-center justify-center text-white text-xs font-bold uppercase">
                {profilePhotoUrl ? (
                  <img src={profilePhotoUrl} alt={`${currentUserName}'s profile`} className="h-full w-full object-cover" />
                ) : currentUserName.substring(0, 2)}
              </div>
              <div className="hidden sm:block text-left">
                <span className="block text-xs font-semibold text-[#001142] max-w-[120px] truncate">
                  {currentUserName}
                </span>
                <span className="block text-[9px] text-[#425aa6] tracking-wider uppercase font-bold">
                  {userRole === "student" ? "Student" : "Recruiter"}
                </span>
              </div>
              <button
                id="logout-btn"
                type="button"
                onClick={onLogout}
                className="p-1 px-2 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-md transition-colors"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
